<?php
// Funções auxiliares

// Valida data futura
function isFutureDate($date) {
    $today = new DateTime();
    $inputDate = new DateTime($date);
    return $inputDate > $today;
}

// Valida horário comercial (08:00-18:00)
function isBusinessHours($time) {
    $hour = (int) explode(':', $time)[0];
    return $hour >= 8 && $hour <= 18;
}

// Verifica se é dia útil (não é fim de semana)
function isWeekday($date) {
    $day = date('N', strtotime($date));
    return ($day < 6); // 1-5 é dia útil
}

// Redireciona com mensagem
function redirectWithMessage($url, $type, $message) {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
    header("Location: $url");
    exit();
}
?>