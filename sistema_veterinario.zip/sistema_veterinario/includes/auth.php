<?php
session_start();

// Verifica se o usuário está logado
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Protege páginas que requerem login
function protectPage() {
    if (!isLoggedIn()) {
        header("Location: ../login.php");
        exit();
    }
}

// Verifica credenciais de login
function login($email, $senha) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($senha, $user['senha'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nome'] = $user['nome'];
        return true;
    }
    return false;
}

// Faz logout
function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>