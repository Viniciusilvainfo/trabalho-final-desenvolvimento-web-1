<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

protectPage();

// Verifica se o ID foi passado
if (!isset($_GET['id'])) {
    redirectWithMessage('dashboard.php', 'danger', 'Consulta não especificada.');
}

$consulta_id = $_GET['id'];

// Verifica se a consulta pertence ao usuário antes de excluir
$stmt = $pdo->prepare("DELETE FROM consultas WHERE id = ? AND id_usuario = ?");
if ($stmt->execute([$consulta_id, $_SESSION['user_id']])) {
    if ($stmt->rowCount() > 0) {
        redirectWithMessage('dashboard.php', 'success', 'Consulta cancelada com sucesso!');
    } else {
        redirectWithMessage('dashboard.php', 'danger', 'Consulta não encontrada ou você não tem permissão para cancelá-la.');
    }
} else {
    redirectWithMessage('dashboard.php', 'danger', 'Erro ao cancelar consulta. Tente novamente.');
}
?>