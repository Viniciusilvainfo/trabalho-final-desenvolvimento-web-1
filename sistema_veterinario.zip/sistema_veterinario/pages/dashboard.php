<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

protectPage();

// Mensagens
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $message_type = $_SESSION['message_type'];
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Logout
if (isset($_GET['logout'])) {
    logout();
}

// Busca consultas do usuário
$stmt = $pdo->prepare("SELECT c.* FROM consultas c WHERE c.id_usuario = ? ORDER BY c.data_consulta, c.hora_consulta");
$stmt->execute([$_SESSION['user_id']]);
$consultas = $stmt->fetchAll();

require_once '../includes/header.php';
?>

<?php if (isset($message)): ?>
    <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
<?php endif; ?>

<h2 class="mb-4">Minhas Consultas</h2>

<?php if (empty($consultas)): ?>
    <div class="alert alert-info">Você não possui consultas agendadas.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Hora</th>
                    <th>Idade do Animal</th>
                    <th>Motivo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($consultas as $consulta): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($consulta['data_consulta'])); ?></td>
                        <td><?php echo date('H:i', strtotime($consulta['hora_consulta'])); ?></td>
                        <td><?php echo $consulta['idade_animal']; ?> anos</td>
                        <td><?php echo $consulta['motivo']; ?></td>
                        <td>
                            <a href="editar_consulta.php?id=<?php echo $consulta['id']; ?>" class="btn btn-sm btn-warning">Editar</a>
                            <a href="excluir_consulta.php?id=<?php echo $consulta['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja cancelar esta consulta?')">Cancelar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<a href="nova_consulta.php" class="btn btn-primary">Agendar Nova Consulta</a>

<?php require_once '../includes/footer.php'; ?>