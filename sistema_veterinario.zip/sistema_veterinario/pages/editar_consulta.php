<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

protectPage();

// Verifica se o ID foi passado
if (!isset($_GET['id'])) {
    redirectWithMessage('dashboard.php', 'danger', 'Consulta não especificada.');
}

$consulta_id = $_GET['id'];

// Busca a consulta para verificar se pertence ao usuário
$stmt = $pdo->prepare("SELECT * FROM consultas WHERE id = ? AND id_usuario = ?");
$stmt->execute([$consulta_id, $_SESSION['user_id']]);
$consulta = $stmt->fetch();

if (!$consulta) {
    redirectWithMessage('dashboard.php', 'danger', 'Consulta não encontrada ou você não tem permissão para editá-la.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idade_animal = filter_input(INPUT_POST, 'idade_animal', FILTER_SANITIZE_NUMBER_INT);
    $data_consulta = filter_input(INPUT_POST, 'data_consulta', FILTER_SANITIZE_STRING);
    $hora_consulta = filter_input(INPUT_POST, 'hora_consulta', FILTER_SANITIZE_STRING);
    $motivo = filter_input(INPUT_POST, 'motivo', FILTER_SANITIZE_STRING);
    
    // Validações (mesmas da nova consulta)
    $errors = [];
    
    if (!isFutureDate($data_consulta)) {
        $errors[] = "A data da consulta deve ser futura.";
    }
    
    if (!isWeekday($data_consulta)) {
        $errors[] = "Consultas só podem ser agendadas em dias úteis (segunda a sexta).";
    }
    
    if (!isBusinessHours($hora_consulta)) {
        $errors[] = "O horário deve ser entre 08:00 e 18:00.";
    }
    
    if (strlen($motivo) < 10) {
        $errors[] = "O motivo deve ter pelo menos 10 caracteres.";
    }
    
    if (empty($errors)) {
        $stmt = $pdo->prepare("UPDATE consultas SET idade_animal = ?, data_consulta = ?, hora_consulta = ?, motivo = ? WHERE id = ? AND id_usuario = ?");
        
        if ($stmt->execute([$idade_animal, $data_consulta, $hora_consulta, $motivo, $consulta_id, $_SESSION['user_id']])) {
            redirectWithMessage('dashboard.php', 'success', 'Consulta atualizada com sucesso!');
        } else {
            $errors[] = "Erro ao atualizar consulta. Tente novamente.";
        }
    }
}

require_once '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <h2 class="mb-4">Editar Consulta</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="idade_animal" class="form-label">Idade do Animal (anos)</label>
                <input type="number" class="form-control" id="idade_animal" name="idade_animal" min="0" max="30" value="<?php echo $consulta['idade_animal']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="data_consulta" class="form-label">Data da Consulta</label>
                <input type="date" class="form-control" id="data_consulta" name="data_consulta" value="<?php echo $consulta['data_consulta']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="hora_consulta" class="form-label">Hora da Consulta</label>
                <input type="time" class="form-control" id="hora_consulta" name="hora_consulta" min="08:00" max="18:00" value="<?php echo $consulta['hora_consulta']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="motivo" class="form-label">Motivo da Consulta</label>
                <textarea class="form-control" id="motivo" name="motivo" rows="3" required><?php echo $consulta['motivo']; ?></textarea>
                <small class="text-muted">Mínimo 10 caracteres</small>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>