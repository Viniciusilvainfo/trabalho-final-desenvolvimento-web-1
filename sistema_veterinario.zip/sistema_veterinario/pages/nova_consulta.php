<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

protectPage();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idade_animal = filter_input(INPUT_POST, 'idade_animal', FILTER_SANITIZE_NUMBER_INT);
    $data_consulta = filter_input(INPUT_POST, 'data_consulta', FILTER_SANITIZE_STRING);
    $hora_consulta = filter_input(INPUT_POST, 'hora_consulta', FILTER_SANITIZE_STRING);
    $motivo = filter_input(INPUT_POST, 'motivo', FILTER_SANITIZE_STRING);
    
    // Validações
    $errors = [];
    
    if (!isFutureDate($data_consulta)) {
        $errors[] = "A data da consulta deve ser futura.";
    }
    
    if (!isWeekday($data_consulta)) {
        $errors[] = "Consultas só podem ser agendadas em dias úteis (segunda a sexta).";
    }
    
    if (!isBusinessHours($hora_consulta)) {
        $errors[] = "O horário deve ser entre 08:00 e 18:00.";
    }
    
    if (strlen($motivo) < 10) {
        $errors[] = "O motivo deve ter pelo menos 10 caracteres.";
    }
    
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO consultas (id_usuario, idade_animal, data_consulta, hora_consulta, motivo) VALUES (?, ?, ?, ?, ?)");
        
        if ($stmt->execute([$_SESSION['user_id'], $idade_animal, $data_consulta, $hora_consulta, $motivo])) {
            redirectWithMessage('dashboard.php', 'success', 'Consulta agendada com sucesso!');
        } else {
            $errors[] = "Erro ao agendar consulta. Tente novamente.";
        }
    }
}

require_once '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <h2 class="mb-4">Agendar Nova Consulta</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="idade_animal" class="form-label">Idade do Animal (anos)</label>
                <input type="number" class="form-control" id="idade_animal" name="idade_animal" min="0" max="30" required>
            </div>
            <div class="mb-3">
                <label for="data_consulta" class="form-label">Data da Consulta</label>
                <input type="date" class="form-control" id="data_consulta" name="data_consulta" required>
            </div>
            <div class="mb-3">
                <label for="hora_consulta" class="form-label">Hora da Consulta</label>
                <input type="time" class="form-control" id="hora_consulta" name="hora_consulta" min="08:00" max="18:00" required>
            </div>
            <div class="mb-3">
                <label for="motivo" class="form-label">Motivo da Consulta</label>
                <textarea class="form-control" id="motivo" name="motivo" rows="3" required></textarea>
                <small class="text-muted">Mínimo 10 caracteres</small>
            </div>
            <button type="submit" class="btn btn-primary">Agendar</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>