// Validação do formulário no cliente
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // Validações adicionais podem ser adicionadas aqui
            return true;
        });
    });
    
    // Atualiza o minDate para o datepicker (amanhã)
    const dateInput = document.getElementById('data_consulta');
    if (dateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const minDate = tomorrow.toISOString().split('T')[0];
        dateInput.min = minDate;
    }
});